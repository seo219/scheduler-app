// src/constants/typeColors.js
export const TYPE_COLORS = {
  sleep:  '#FFFFFF',
  meal:   '#F5F5F5',
  fixed:  '#E0E0E0',
  todo:   '#F0F0F0',
  holiday:'#FFFFFF',
};
