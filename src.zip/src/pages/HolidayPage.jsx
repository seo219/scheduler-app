import React from 'react';

export default function CalendarPage() {
  return <h1>📅 휴일 페이지</h1>;
}
